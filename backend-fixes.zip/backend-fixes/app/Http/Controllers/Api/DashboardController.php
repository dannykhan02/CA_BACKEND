<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Document;
use App\Policies\DocumentPolicy;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function summary(Request $request): JsonResponse
    {
        // Previously counted across ALL documents regardless of the caller's
        // role — a Viewer could infer the existence/volume of Restricted
        // documents from aggregate counts alone (audit F-High-2). Now scoped
        // identically to DocumentController::index().
        $allowedClassifications = DocumentPolicy::allowedClassificationsFor($request->user());

        $counts = Document::query()
            ->whereIn('classification', $allowedClassifications)
            ->selectRaw('status, count(*) as total')
            ->groupBy('status')
            ->pluck('total', 'status');

        $total = $counts->sum();

        return response()->json([
            'data' => [
                'total' => $total,
                'ready' => (int) ($counts['Ready'] ?? 0),
                'processing' => (int) ($counts['Processing'] ?? 0),
                'needsReview' => (int) ($counts['Needs Review'] ?? 0),
                'failed' => (int) ($counts['Failed'] ?? 0),
            ],
        ]);
    }
}

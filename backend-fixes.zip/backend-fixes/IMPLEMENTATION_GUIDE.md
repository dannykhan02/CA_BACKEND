# Implementation Guide — Audit Fixes + Hardening Additions

Every file here is a drop-in replacement for the matching path in your Laravel app
(paths match exactly: `app/...`, `database/migrations/...`). Copy them over the
existing files. New files (new classes, new migration) just need to land in place.

Applied in the order below, oldest/most-critical first. **Do the migration and
composer step before deploying the PHP changes that depend on them** — a few
fixes require a schema change or a new package first, called out explicitly.

---

## 0. Prerequisites (do these first)

```bash
composer require firebase/php-jwt

# Only needed if you're on Laravel < 11: the OTP-column-widening migration
# below uses Schema::table(...)->change(), which requires doctrine/dbal on
# older Laravel versions. Laravel 11+ handles this natively for most drivers
# — check your composer.json's laravel/framework version before skipping this.
composer require doctrine/dbal --dev

php artisan migrate   # runs both new migrations below
```

- `database/migrations/2026_08_02_000000_create_audit_logs_table.php` — new `audit_logs` table.
- `database/migrations/2026_08_02_000001_widen_otp_columns_for_hashing.php` — **must run before** the updated `AuthController`/`VerificationCode` code is deployed, or the first hashed OTP write will be truncated and break verification for every user until fixed.

Add to `.env`:
```
HORIZON_AUTHORIZED_EMAILS=you@example.com,teammate@example.com
```

Register the new Artisan command and middleware (Laravel 11+ style, `bootstrap/app.php`):
```php
->withMiddleware(function (Middleware $middleware) {
    $middleware->append(\App\Http\Middleware\SecurityHeaders::class);
})
```
(If you're on the Kernel-based structure instead, add `SecurityHeaders::class` to the `$middleware` array in `app/Http/Kernel.php`.)

---

## 1. CRITICAL — deploy immediately

| File | Fix |
|---|---|
| `app/Http/Controllers/Api/DocumentDownloadController.php` | Was a duplicate `DocumentController` class (copy/paste error) with no download logic and no auth check at all. Rewritten with the correct class name, `authorize('view', $document)`, a status guard, and a real `Storage::download()` call. |
| `app/Http/Controllers/Api/DocumentUploadController.php` | The upload-dedup path returned full document metadata for an existing file before checking whether the uploader could view its classification. Now gates that response behind the same `view` policy check. |

**Verify after deploy:** hit `/api/documents/{id}/download` as a Viewer against a Restricted document and confirm 403; hit it as a Reviewer against a document they can see and confirm the file actually streams with the right filename.

---

## 2. HIGH — next sprint

| File | Fix |
|---|---|
| `app/Http/Controllers/Api/AuthController.php` | `signin()` now returns one generic message/status for bad password, deactivated, and unverified accounts (previously distinguishable → enumeration). Also adds a secondary IP-only rate limiter, removes the leftover `TRACE` logs, and switches OTP comparisons to `Hash::check()` (paired with the `VerificationCode` change). |
| `app/Http/Controllers/Api/DashboardController.php` | `summary()` now scopes counts through `DocumentPolicy::allowedClassificationsFor()`, matching `DocumentController::index()`. |
| `app/Http/Controllers/Api/DocumentReprocessController.php` + `app/Policies/DocumentPolicy.php` | Reprocess now goes through a new `reprocess()` policy ability instead of an inline role check, so it's classification-aware like approve/reject. |
| `app/Services/GoogleTokenVerifier.php` (new) + `AuthController::google()` | Replaces the legacy `/tokeninfo` call with local JWT signature verification against Google's cached JWKS. Requires `firebase/php-jwt` (see Prerequisites). |

**Verify after deploy:** attempt signin with a wrong password vs. a deactivated account vs. an unverified account and confirm the response body/status is now identical in all three cases; confirm Google sign-in still works end-to-end (this is the one change here with real external-dependency risk — test against a real Google ID token in staging before prod).

---

## 3. MEDIUM

| File | Fix |
|---|---|
| `app/Http/Controllers/Admin/UserController.php` | `updateRole()` now refuses to demote the last remaining active Administrator. |
| `app/Providers/HorizonServiceProvider.php` | Gate reads `HORIZON_AUTHORIZED_EMAILS` from `.env` instead of a permanently empty array. **You must set this env var** or Horizon stays inaccessible exactly as before. |
| `app/Http/Controllers/Api/AuthController.php` | (same file as above) `confirmEmailChange()` — removed the two `TRACE` log lines that logged old/new email PII unconditionally in all environments; wrapped the final `save()` in a transaction + catch for the `pending_email` race condition, returning a clean 409 instead of a raw 500. |

---

## 4. LOW

| File | Fix |
|---|---|
| `app/Support/EscapesLikeWildcards.php` (new) + `app/Http/Controllers/Api/DocumentController.php` | Escapes `%`/`_` in the `q` and `author` search filters so a literal percent/underscore in a search term behaves as expected. Not a security fix (queries were already parameterized) — a correctness one. |
| `app/Jobs/ScanUploadedFileJob.php` + `app/Exceptions/MalwareScannerUnavailableException.php` (new) | "Scanner unreachable" now throws a distinct exception and logs at `critical` level, separately from "malware found" — so you can page on the former without confusing it with routine rejected uploads. |
| `app/Console/Commands/CheckProductionSafetyConfig.php` (new) | `php artisan config:check-production-safety` — wire into your deploy pipeline as a hard gate. Fails the build if `expose_verification_code`, `expose_password_reset_token`, or `app.debug` are `true` in production, or if `clamav_enabled` is not `true`. |
| `app/Models/User.php` | Added a doc comment on `sendPasswordResetNotification()` cross-referencing `AuthController::forgotPassword()`, so the two parallel password-reset notification paths aren't mistaken for accidental duplication later. |

---

## 5. Additional hardening (not in the original audit — found on this pass)

These are real gaps I found while re-reading the code for this round, beyond what the first audit covered. None are exotic — they're the kind of thing worth doing now while you're already in this code.

### 5.1 OTP codes were stored in plaintext
`VerificationCode.code` and `User.pending_email_code` were compared via a direct DB `WHERE code = ?` — meaning both columns held the raw 6-digit code in the clear. Anyone with read access to a DB backup, replica, or admin tool could read live, usable OTPs. Laravel's own password-reset broker already hashes its tokens at rest (`Password::broker()->createToken()`); this brings email-verification and email-change codes to the same standard.

- `app/Models/VerificationCode.php` — `generateFor()` now stores `Hash::make($code)` and exposes the plaintext only via a transient, non-persisted `$plainCode` property for the caller to email out once.
- `AuthController` — `verifyEmail()` and `confirmEmailChange()` now use `Hash::check()` instead of an equality lookup.
- Requires the widened-column migration (see Prerequisites) run first.

### 5.2 Notifications weren't actually queued
Every notification class did `use Queueable;` but none `implements ShouldQueue`. The trait alone has no effect — without the interface, Laravel sends the mail **synchronously**, inside the request or job that called `->notify()`. That means signup, resend, forgot-password, email-change, etc. were all blocking on a live SMTP/API round-trip to your mail provider before returning a response, and a slow or down provider degrades or fails an otherwise-successful action.

Fixed in all 6 notification classes that needed it (`VerificationCodeNotification`, `EmailChangeVerificationNotification`, `EmailChangedNotification`, `PasswordChangedNotification`, `PasswordResetNotification`, `ResetPasswordNotification`, `WelcomeNotification`) by adding `implements ShouldQueue`.

One tradeoff worth knowing: `EmailChangedNotification` and `PasswordChangedNotification` are security alerts ("did you mean to do this?"). Queuing them means their delivery speed now depends on queue worker health. If you don't already monitor queue depth/latency, consider a dedicated, closely-watched queue for security-alert notifications specifically, rather than the default queue.

### 5.3 No audit trail for document actions
There was no record of who viewed, downloaded, approved, rejected, or reprocessed a specific document — only `last_updated_by`, which gets overwritten on every action and keeps no history. For a product that classifies documents as Confidential/Restricted, this is close to table-stakes for a compliance investigation.

Added:
- `database/migrations/..._create_audit_logs_table.php` — append-only `audit_logs` table (polymorphic `auditable`, small JSON `metadata`, IP, timestamp — deliberately no `updated_at`).
- `app/Models/AuditLog.php`
- `app/Services/AuditLogger.php` — thin wrapper, injected into controllers.
- Wired into `DocumentDownloadController`, `DocumentApproveController`, `DocumentRejectController`. `DocumentReprocessController` and `show()` were left as an exercise if you want view-level (not just mutation-level) logging — be aware that logging every `show()` call adds a write per document view, which is more volume; decide based on your actual compliance requirement rather than logging everything by default.

### 5.4 No baseline security response headers
Added `app/Http/Middleware/SecurityHeaders.php` (`X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`, `Permissions-Policy`, conditional `Strict-Transport-Security`). Register it globally — see Prerequisites.

---

## 6. Recommended but NOT implemented here (needs product/infra decisions first)

Flagging these rather than guessing at your infrastructure:

- **Sanctum token ability scoping.** Every token is currently created with `['*']` — full abilities regardless of role. Scoping tokens (e.g. `$user->createToken('auth-token', ["role:{$user->role}"], ...)` plus an ability-check middleware on sensitive routes) would mean a leaked token is bounded by what it was issued for. This touches every `createToken()` call and needs you to decide the ability taxonomy — didn't want to invent one for you.
- **MFA/TOTP for Administrator and Reviewer accounts**, given they can see Restricted documents and (for Admins) change other users' roles. Real feature — new column(s), a setup/verify flow, recovery codes — worth scoping as its own piece of work rather than bolting on here.
- **`config/filesystems.php` review** — confirm the `documents` disk isn't also reachable via a public URL that bypasses `DocumentDownloadController`'s policy check entirely. I flagged this as a question in the first review; couldn't confirm without that config file.
- **CSP header** — omitted from `SecurityHeaders` deliberately; a `Content-Security-Policy` for a pure JSON API usually isn't meaningful the way it is for an HTML app, and a wrong one can break API responses others consume (e.g. Swagger/API doc UIs). Worth adding only if you know exactly what's allowed to embed/call this API.
